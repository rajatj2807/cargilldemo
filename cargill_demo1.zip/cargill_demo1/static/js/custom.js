var result="";


function delete_row(no)
{
 document.getElementById("row"+no+"").outerHTML="";
 $("#searchCriteria").val('no');
}
var no = 1;
function add_row()
{
 var f1=document.getElementById("f1").value;
 var o1=document.getElementById("o1").value;
 //var c1=document.getElementById("c1").value;
 var v1=document.getElementById("v1").value;
 var AND=document.getElementById("AND").checked;
 var OR=document.getElementById("OR").checked;
 
 var table=document.getElementById("tbl");
 var table_len=(table.rows.length)-1;
 var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='field_row"+table_len+"' ><input type='text' name='field_row"+no+"'value='"+f1+"' id='field_row"+no+"' ></td><td id='operation_row"+table_len+"'><input type='text' name='operation_row"+no+"'value='"+o1+"' id='operation_row"+no+"' ></td><td id='value_row"+table_len+"' ><input type='text' name='value_row"+no+"'value='"+v1+"' id='value_row"+no+"'></td><td><input type='radio' name='options"+no+"' id='AND"+no+"'> / <input type='radio' name='options"+no+"' id='OR"+no+"'></td><td><button type='button' class='btn btn-primary' onclick='delete_row("+table_len+")'> Delete </button></td></tr>";
 if(AND){
    document.getElementById("AND"+no+"").checked = true;
 }else{
    document.getElementById("OR"+no+"").checked = true;
 }
 //document.getElementById("f1").value="";
 //document.getElementById("o1").value="";
 document.getElementById("v1").value="";
 no++;
}


function file_delete_row(num)
{
 document.getElementById("file_row"+num+"").outerHTML="";
}
var num=1;
function file_add_row()
{
 var f2=document.getElementById("f2").value;
 var c1=document.getElementById("c1").value;
 
 var table=document.getElementById("file_tbl");
 var table_len=(table.rows.length)-1;
 var row = table.insertRow(table_len).outerHTML="<tr id='file_row"+table_len+"'><td id='file_field"+table_len+"'><input type='text' name='file_field"+num+"'value='"+f2+"' id='file_field"+num+"'></td><td id='custList_row"+table_len+"'><input type='text' name='custList_row"+num+"'value='"+c1+"' id='custList_row"+num+"'></td><td><button type='button' class='btn btn-primary' onclick='file_delete_row("+table_len+")'> Delete </button></td></tr>";
 
 //document.getElementById("f2").value="";

 
 num++;
}


jQuery(document).ready(function($) {
	$("#reset").click(function(){
		document.getElementById("salesForm").reset();
		document.getElementById("search_leftAll").click();
		var table = document.getElementById("result").DataTable;
		if(result){
			$("#result").DataTable().destroy();
			$("#result").empty();
			result = "";
		}
		
		var rowCount = document.getElementById('tbl').rows.length;
		
		rowCount= rowCount-1;
		
		for(i=1; i< rowCount ; i++) {
			document.getElementById("row"+i+"").outerHTML="";
		}
		alert("Reset Successful.")
	});

	$("#reset1").click(function(){
		document.getElementById("partsForm").reset();
		document.getElementById("search_leftAll").click();
		var table = document.getElementById("result").DataTable;
		if(result){
			$("#result").DataTable().destroy();
			$("#result").empty();
			result = "";
		}
		
		var rowCount = document.getElementById('tbl').rows.length;
		
		rowCount= rowCount-1;
		
		for(i=1; i< rowCount ; i++) {
			document.getElementById("row"+i+"").outerHTML="";
		}
		alert("Reset Successful.")
	});

	
	$('#search').multiselect({
	    search: {
	        left: '<input type="text" name="q" class="form-control" placeholder="Search"/>',
	        right: '<input type="text" name="q" class="form-control" placeholder="Search" />'
	    },
	    fireSearch: function(value) {
	        return value.length > 0;
	    }
	});
	
	$("#downloadTemplate").click(function(){
		var xls_name = $("#file_name").val();
		window.location.href = "/downloadTemplate/"+xls_name;
	});
	
	$("#uploadExcel").click(function(){
		$(".custom-loader").show();
		var form = document.getElementById('poeeInWorkData');
		var formData = new FormData(form);
		$.ajax({
			url: '/UploadFile',
			type: "POST",
			cache: false,
			data: formData,
			contentType: false,
			processData: false,      
			success: function(result){
				if (result == "success"){
					 //toastr.success('File data uploaded successfully.');
					$("#successMessage").text('File data uploaded successfully');
					$('#success').removeClass('hide');
					setTimeout(function() {
						$('#success').addClass('hide');
					}, 10000);
					
				}
				if (result == "failed"){
					//alert("failed");
				
					//toastr.error('File upload failed');
					$("#failedMessage").text("File upload failed");
					$('#failed').removeClass('hide');
					setTimeout(function() {
						$('#failed').addClass('hide');
					}, 10000);
				}
				if (result == "invalid"){
					toastr.warning('Invalid input');
					/*$("#failedMessage").text('Please provide valid input');
					$('#failed').removeClass('hide');
					setTimeout(function() {
						$('#failed').addClass('hide');
					}, 10000);*/
				}
				$("#file").val("");
				document.getElementById('uploadExcel').disabled = true;
				$(".custom-loader").hide();
			},//success close
			error: function () {
				$(".custom-loader").hide();
				$("#failedMessage").text("Data upload failed");
				$('#failed').removeClass('hide');
				setTimeout(function() {
					$('#failed').addClass('hide');
				}, 10000);
			}
		});//ajax close
	});//click function close
	
	$('#file_name').on('change',function() {
		var team_name = $('#file_name').val();
		$('#file').val("");
		if (team_name == ''){
			document.getElementById('file').disabled = true;
			document.getElementById('uploadExcel').disabled = true;
			document.getElementById('downloadTemplate').disabled = true;
		}
		else{
			document.getElementById('file').disabled = false;
			document.getElementById('uploadExcel').disabled = true;
			document.getElementById('downloadTemplate').disabled = false;
		}
	});
	
	$('#file').on('change',function() {
		var fileName = $('#file').val();
		var ext = (fileName.match(/\.([^\.]+)$/)[1]).toLowerCase();
		if (ext != "xlsx" && ext!="xls"){
			alert("File type not allowed.");
			$('#file').val("");
			document.getElementById('uploadExcel').disabled = true;
			return false;
		}
		if(!fileName){
			document.getElementById('uploadExcel').disabled = true;
		}
		else{
			document.getElementById('uploadExcel').disabled = false;
		}
	});//end file change()
	
	$("#searchField").hide();
	$("#salesSubmit").click(function(){
		var myOpts = document.getElementById('search_to').options;
 		var text = "";
 		var dy_columns = [];
 		for (i=0 ; i<myOpts.length;i++){
 			if (i == (myOpts.length -1)){
 				text = text + myOpts[i]['text'];
 				dy_columns[i] = {'title' : myOpts[i]['text'] };
 			}
 			else{
 				text =text + myOpts[i]['text'] +",";
 				dy_columns[i] = {'title' : myOpts[i]['text'] };
 			}
 		}
 		//console.log(dy_columns);
 		$("#searchField").val(text);
		var form_name = 'sales';
 		var form = document.getElementById('salesForm');
		/*if (form)
			form_name = 'sales';
		else{
			var form = document.getElementById('partsForm');
			form_name = 'parts'
		}*/

 		var formData = new FormData(form);
 		$("#collapseFour").addClass('show');
 		
 		$("#result_processing").show();
 		//show loader on click and remove after ajax call
 		$.ajax({
 		   		 url: '/adhocQuery/'+form_name,
 		   		 type: "POST",
 		   		 cache: false,
 		   		 data: formData,
 		   		 contentType: false,
 		   	     processData: false,
 		   		 success: function(result_data){
 		   			if (result_data['message'] == "success"){
 		   					
		 		   			if (result){
		 		    			$('#result').DataTable().destroy();
		 		    			$('#result').empty();
		 		    		}
		 		   			
	 		   				//datatable re-created with new values and headers
		 		   			result = $('#result').DataTable({
		 		   			dom: 'Bfrtip',
		 		   			destroy: true,
		 		   		    language: {
		 		   		        processing: "<img src='/static/images/loading.gif'>"
		 		   		    },
		 		   		    buttons: ['copy', 'csv', 'excel', 'pdf'],
		 		   		    processing: true,
		 		   		    data:result_data['data'],
			 		   		columns: dy_columns
		 		   			});//datatable end
 		   			}
 		 	        if (result_data['message'] == "failed"){
 		 	        	  $("#failedMessage").html('Please provide valid input');
 		  	         	  $('#failed').removeClass('hide');
 		  	         	  setTimeout(function() {
 		  		             $('#failed').addClass('hide');
 		  		             }, 10000);
 		 	        }
 		   		 }//success() close
 			});//ajax close
 	});// end sales click()

	
	$("#partsSubmit").click(function(){
		console.log('parts');
		var myOpts = document.getElementById('search_to').options;
 		var text = "";
 		var dy_columns = [];
 		for (i=0 ; i<myOpts.length;i++){
 			if (i == (myOpts.length -1)){
 				text = text + myOpts[i]['text'];
 				dy_columns[i] = {'title' : myOpts[i]['text'] };
 			}
 			else{
 				text =text + myOpts[i]['text'] +",";
 				dy_columns[i] = {'title' : myOpts[i]['text'] };
 			}
 		}
 		//console.log(dy_columns);
 		var value = $("#value_row1").val();
 		if (value){
 			$("#searchCriteria").val('yes');
 		}
 		else{
 			$("#searchCriteria").val('no');
 		}
 		$("#searchField").val(text);
		var form_name = 'parts';
		
		var form = document.getElementById('partsForm');
 		var formData = new FormData(form);
 		$("#collapseFour").addClass('show');
 		
 		$("#result_processing").show();
 		//show loader on click and remove after ajax call
 		$.ajax({
 		   		 url: '/adhocQuery/'+form_name,
 		   		 type: "POST",
 		   		 cache: false,
 		   		 data: formData,
 		   		 contentType: false,
 		   	     processData: false,
 		   		 success: function(result_data){
 		   			if (result_data['message'] == "success"){
		 		   			if (result){
		 		    			$('#result').DataTable().destroy();
		 		    			$('#result').empty();
		 		    		}
		 		   			
	 		   				//datatable re-created with new values and headers
		 		   			result = $('#result').DataTable({
		 		   			dom: 'Bfrtip',
		 		   			destroy: true,
		 		   			buttons: [ 'copy', 'csv', 'excel', 'pdf'],
		 		   		    language: {
		 		   		        processing: "<img src='/static/images/loading.gif'>"
		 		   		    },
		 		   		    processing: true,
		 		   		    data:result_data['data'],
			 		   		columns: dy_columns
		 		   			});//datatable end
 		   			}
 		   		 }//success() close
 			});//ajax close
 	});// end sales click()
	
});//document close
			
			